import paho.mqtt.client as mqtt

mqttp=mqtt.Client('Prueba')

mqttp.connect('test.mosquitto.org',1883)
mqttp.publish('prueba','Hola Mundo')
