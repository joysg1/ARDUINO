import paho.mqtt.client as mqtt

# Define la función de callback para cuando se conecta al servidor MQTT
def on_connect(client, userdata, flags, reason_code, properties):
    if reason_code == 0:
        print("Conectado al servidor MQTT")
        # Suscribe al tópico después de conectarse exitosamente
        client.subscribe("mi_topic")
    else:
        print(f"Error al conectar al servidor MQTT: {reason_code}")

# Define la función de callback para cuando se recibe un mensaje
def on_message(client, userdata, msg):
    print(f"Mensaje recibido en {msg.topic}: {msg.payload.decode('utf-8')}")

# Crea un cliente MQTT con la versión de API de callbacks 2 (la más reciente)
mqtts = mqtt.Client(callback_api_version=mqtt.CallbackAPIVersion.VERSION2, client_id='Prueba')

# Configura las funciones de callback
mqtts.on_connect = on_connect
mqtts.on_message = on_message

try:
    # Conecta al servidor MQTT
    mqtts.connect("test.mosquitto.org", 1883)
    print("Intentando conectar al servidor MQTT...")
    
    # Inicia el bucle principal del cliente MQTT
    mqtts.loop_forever()
    
except ConnectionRefusedError:
    print("Error: No se pudo conectar al servidor MQTT en localhost:1883")
    print("Asegúrate de que el broker MQTT (Mosquitto) esté instalado y corriendo")
    print("\nPara instalar y ejecutar Mosquitto:")
    print("  sudo apt install mosquitto mosquitto-clients")
    print("  sudo systemctl start mosquitto")
    print("  sudo systemctl enable mosquitto")
except Exception as e:
    print(f"Error inesperado: {e}")