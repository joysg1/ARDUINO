import serial
import paho.mqtt.client as mqtt

try:
    arduino=serial.Serial('COM5',9600)
    print('Arduino connected')
except:
    print('Failed to connect Arduino')

def on_connect(mqtts, userdata, flags, rc):
    print('Connected with result code '+str(rc))
    mqtts.subscribe('test')

def on_message(mqtts, userdata, msg):
    datos = msg.payload
    datos = datos.decode("utf-8")
    arduino.write(datos.encode("utf-8"))
    print(datos)

mqtts = mqtt.Client('Prueba')
mqtts.on_connect = on_connect
mqtts.on_message = on_message
mqtts.connect('test.mosquitto.org', 1883) 
mqtts.loop_forever()   
