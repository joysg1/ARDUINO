int led = 6;

void setup() {
  Serial.begin(9600);
  pinMode(led, OUTPUT);
}   


void loop() {

if (Serial.available() > 0) {
  char dato = Serial.read();

  if (dato == '1') {
    digitalWrite(led, HIGH);
  } else if (dato == '0') {
    digitalWrite(led, LOW);
  }


  
}

} 
