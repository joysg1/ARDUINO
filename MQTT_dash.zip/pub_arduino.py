import serial, time
import paho.mqtt.client as mqtt

mqttp= mqtt.Client('Prueba')

try:
    arduino = serial.Serial('COM5',9600)
    mqttp.connect('test.mosquitto.org', 1883)
except:
    print('Error de conexion')

while True:
    time.sleep(1)
    datos = arduino.readline()
    datos = datos.decode('utf-8')    
    print(datos)
    mqttp.publish('prueba', datos)