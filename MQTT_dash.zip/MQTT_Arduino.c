int pot = A0;

void setup() {
  Serial.begin(9600);
}

void loop() {
  int valor = analogRead(pot);
  int mapeo = map(valor, 0, 1023, 0, 255);
  Serial.println(mapeo);
  delay(1000);
}
